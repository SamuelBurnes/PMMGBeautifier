import { Module } from "./ModuleRunner";
import { getBuffers} from "./util";//createTextSpan, genericCleanup, genericUnhide
import { Selector } from "./Selector";
import { WithStyles, Style } from "Style";


export class CompactUI implements Module {
    private tag = "pb-compactui";
    //private username;
    private result;
	//private contracts;
	constructor(result)
	{
        this.result = result;
		//this.username = username;
	}
	

    cleanup() {
        //genericCleanup(this.tag);
        //genericUnhide(this.tag);
    }
    run() {
        var buffers = getBuffers("BBL");
        //console.log("Clearning Buildings");
        if (buffers){
            buffers.forEach(buffer => {
                ClearBuildingLists(buffer, this.result, this.tag);
            });
        };
        
        buffers = getBuffers("BS");

        if (buffers){
            buffers.forEach(buffer => {
                ClearBase(buffer, this.tag);
            });
        };
        return;
    }
}

export function HideElement(element, tag)
{
    element.style.display = "none";
    element.classList.add(tag + "-hidden")
}
export function UnHideElement(element, tag)
{
    element.style.display = "";
    element.classList.remove(tag + "-hidden")
}

export function ClearBuildingLists(buffer, result, tag)
{
	const nameElem = buffer.querySelector(Selector.BuildingList);
	if(!nameElem || !nameElem.textContent) return;
	//console.log("Clearning Buildings");

    Array.from(buffer.querySelectorAll(Selector.Divider) as HTMLElement[]).forEach((row) => {
        //console.log(row);
        if(row.childNodes.length < 2)
        {
            var newmenu = document.createElement("span");
            var indicator = document.createElement("div");
            var value = document.createElement("div");
            newmenu.classList.add(...WithStyles(Style.RadioButton))
            indicator.classList.add(...WithStyles(Style.RadioButtonToggled))
            value.classList.add(...WithStyles(Style.RadioButtonValue))
            value.innerText = "Visible"
            row.appendChild(newmenu)
            newmenu.appendChild(indicator)
            newmenu.appendChild(value)
            newmenu.addEventListener("click", function () {
                if(indicator.classList.contains(Style.RadioButtonToggled[1]))
                {
                    if(row.nextElementSibling)
                        HideElement((row.nextElementSibling as HTMLElement), tag)
                    indicator.classList.remove(...WithStyles(Style.RadioButtonToggled))
                    indicator.classList.add(...WithStyles(Style.RadioButtonUnToggled))
                }
                else
                {
                    if(row.nextElementSibling)
                        UnHideElement((row.nextElementSibling as HTMLElement), tag)
                    indicator.classList.remove(...WithStyles(Style.RadioButtonUnToggled))
                    indicator.classList.add(...WithStyles(Style.RadioButtonToggled))
                }
            });
            //console.log(row.innerText);
            if( row.innerText.includes("Infrastructure"))
            {
                console.log(row);
                var event = new CustomEvent("click", { "detail": "fake click" });
                newmenu.dispatchEvent(event);
            }
        }
    });


    Array.from(nameElem.getElementsByTagName("table")).forEach((table : HTMLTableElement) => {
        
        var repaired = false;

        var EstablishRow;

        var buttons = (table.parentNode as HTMLElement).getElementsByTagName("button")
        buttons[1].classList.remove(...WithStyles(Style.ButtonEnabled))
        buttons[1].classList.add(...WithStyles(Style.ButtonDanger))

        Array.from(table.rows).forEach(row => {
            
            //console.log(text);
            enum Line {
                Established,
                Repair,
                Cost,
                Refund,
                Value,
                Condition
            }
            var dict = {
                'Established' : Line.Established,
                'Last repair' : Line.Repair,
                'Repair costs' : Line.Cost,
                'Reclaimable materials' : Line.Refund,
                'Book value' : Line.Value,
                'Condition' : Line.Condition
            };
    
            var linetype = Line.Established
            
            Array.from(row.getElementsByTagName("td")).forEach(data => {
                //console.log(data.innerText);

                var text = data.innerText 
                //console.log("TEXT " + text);
                //console.log("CLIN " + linetype);
                if (dict[text] != null) 
                {
                    linetype = dict[text]
                    //console.log("NLIN " + Line[linetype]);

                    if(linetype == Line.Established)
                        EstablishRow = row;
                }
                else if(text == "--")
                    HideElement(row, tag);
                else if(text == "none")
                    HideElement(row, tag);
                else
                {
                    
                    text.split(" ").forEach(word => {
                        var value = parseFloat(word)
                        if(!Number.isNaN(value))
                        {
                            //console.log(value);
                            if(linetype == Line.Repair)
                                repaired = true;
                            if(linetype == Line.Condition || linetype == Line.Established || linetype == Line.Repair)
                            {
                                var bar = data.getElementsByTagName("progress");
                                if(value > 180)
                                    HideElement(row, tag);
                                
                                else if(bar != null && bar.length > 0)
                                {
                                    //console.log(bar);
                                    bar[0].classList.remove(...WithStyles(Style.ProgressBarColors));
                                    bar[0].value = value
                                    var progress = bar[0].value / bar[0].max
                                    if(linetype == Line.Condition)
                                    {

                                        if(value > 98 && buttons[0].classList.contains(Style.ButtonEnabled[0]))
                                        {
                                            buttons[0].classList.remove(...WithStyles(Style.ButtonEnabled))
                                            buttons[0].classList.add(...WithStyles(Style.ButtonDanger))
                                            //buttons[0].removeEventListener()
                                        }
                                        if(progress > 0.90)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarGood))
                                        else if(progress > 0.80)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarWarning))
                                        else if(progress > 0)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarDanger))
                                    }
                                    else
                                    {
                                        bar[0].value = 180 - value
                                        progress = bar[0].value / bar[0].max
                                        var threshold = result["PMMGExtended"]["repair_threshold"] ? result["PMMGExtended"]["repair_threshold"] / 180.0 : (70.0 / 180.0);
                                        if(progress > 0.75)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarGood))
                                        else if(progress > threshold)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarWarning))
                                        else if(progress > 0)
                                            bar[0].classList.add(...WithStyles(Style.ProgressBarDanger))
                                    }


                                }
                                else
                                {
                                    //console.log(row);
                                    var newbar = document.createElement("progress");

                                    //console.log(newbar.classList);                           
                                    newbar.classList.add(...WithStyles(Style.ProgressBar));
                                    if(linetype == Line.Condition)
                                        newbar.max = 100
                                    else
                                        newbar.max = 180
                                    data.innerHTML = newbar.outerHTML + data.innerHTML
                                }

                            }
                            else if(linetype == Line.Value && value < 2000)
                                HideElement(row, tag);  
                            else if(value <= 1)
                                HideElement(row, tag);
                        }

                    });
                }
            });

            if(repaired)
                HideElement(EstablishRow, tag);

        });
    });
    
}

export function ClearBase(buffer, tag)
{

    const elements = Array.from(buffer.querySelectorAll(Selector.HeaderRow) as HTMLElement[]);
    if(elements.length == 0){return;}

    elements[0].style.display = "none";
    var editdiv = elements[1].getElementsByTagName("div")[0]
    editdiv.innerHTML = elements[0].getElementsByTagName("progress")[0].outerHTML + editdiv.getElementsByTagName("div")[0].outerHTML;
        
    Array.from(buffer.getElementsByTagName("table")).forEach((table : HTMLTableElement) => {
        Array.from(table.rows).forEach(row => {
            var data = Array.from(row.getElementsByTagName("td"));

            

            /*enum Worker {
                Pioneers = "Pioneers",
                Settlers = "Settlers",
                Technicians = "Technicians",
                Engineers = "Engineers",
                Scientists = "Scientists"
            }*/
    
            if(data.length == 0)
            {
                data = Array.from(row.getElementsByTagName("th"));
                data[2].innerText = "Current";
            }
            else
            {
                //var linetype = Worker[data[0].innerText]
                var required = parseFloat(data[1].innerText);
                var workforce = parseFloat(data[2].innerText.split(" ")[0]);
                //var newworkers = parseFloat(data[2].innerText.split(" ")[1].slice(1,-1));
                var capacity = parseFloat(data[3].innerText);
                
                var bar = data[4].getElementsByTagName("div")[0];

                bar.innerHTML =  bar.getElementsByTagName("progress")[0].outerHTML + bar.getElementsByTagName("progress")[0].title
                bar.style.display = "flex"
                bar.style.flexDirection = "row"

                if(required < 1 && capacity < 1 && workforce < 1)
                    HideElement(row, tag);
            }


        });

    })

}

